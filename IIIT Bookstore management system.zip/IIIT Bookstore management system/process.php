<?php
	session_start();
	$title = "Purchase Successfull";
	require_once "./template/header.php";
// error_reporting(0);
// 	$_SESSION['err'] = 1;
// 	foreach($_POST as $key => $value){
// 		if(trim($value) == ''){
// 			$_SESSION['err'] = 0;
// 		}
// 		break;
// 	}

// 	if($_SESSION['err'] == 0){
// 		header("Location: purchase.php");
// 	} else {
// 		unset($_SESSION['err']);
// 	}

// 	require_once "./functions/database_functions.php";
// 	// print out header here
// 	$title = "Purchase Process";
// 	require "./template/header.php";
// 	// connect database
// 	$conn = db_connect();
// 	extract($_SESSION['ship']);

// 	// validate post section
// 	// $card_number = $_POST['card_number'];
// 	// $card_PID = $_POST['card_PID'];
// 	// $card_expire = strtotime($_POST['card_expire']);
// 	// $card_owner = $_POST['card_owner'];

// 	// find customer
// 	$customerid = getCustomerId($name, $address, $city, $zip_code, $country);
// 	if($customerid == null) {
// 		// insert customer into database and return customerid
// 		$customerid = setCustomerId($name, $address, $city, $zip_code, $country);
// 	}
// 	$date = date("Y-m-d H:i:s");
// 	insertIntoOrder($conn, $customerid, $_SESSION['total_price'], $date, $name, $address, $city, $zip_code, $country);

// 	// take orderid from order to insert order items
// 	$orderid = getOrderId($conn, $customerid);

// 	foreach($_SESSION['cart'] as $isbn => $qty){
// 		$bookprice = getbookprice($isbn);
// 		$query = "INSERT INTO order_items VALUES
// 		('$orderid', '$isbn', '$bookprice', '$qty')";
// 		$result = mysqli_query($conn, $query);
// 		if(!$result){
// 			echo "Insert value false!" . mysqli_error($conn2);
// 			exit;
// 		}
// 	}

// 	session_unset();
?>

<style type="text/css">
	.success-wrapper {
	    width:100%;
	    height:100vh;
	}
	.success-wrapper {
		width:100%;
	    height:100vh;
	    background:#000;
	    overflow-x:hidden;
	    overflow-y:hidden;
	    padding:6% 2%;
	}
	.page-wrapper {
		top:30%;
	}
</style>
	
	<section class="success-wrapper">
		<div class="container">
			<div class="page-wrapper text-center">
				<div class="d-flex flex-column">
					<div class="header">
						<img src="./images/oc1.png" class="img-fluid" width=120 height=120/>
					</div>
					<div class="body"><br>
						<h4 class="text-light">Your order has been processed sucessfully! <span class="fa fa-check-circle text-success"></span></h4><br>
						<p class="text-primary">Please check your email to get your order confirmation and shipping detail!</p>
						<p class="text-primary">You will receive your ordered books within 7 days of time</p>
					</div>
					<div class="conclude">
						<a href="index.php" class="btn btn-primary"><span class="fa fa-home"></span>&nbsp;Back Home</a>
					</div>
				</div>
			</div>
		</div>		
	</section>

<?php
	// if(isset($conn)){
	// 	mysqli_close($conn);
	// }
	require_once "./template/footer.php";
?>
