
<?php
  session_start();  
  $title = "Team";
  require_once "./template/header.php";
?>

	<style type="text/css">
		.font-lucida {
			font-family: 'Lucida Console', 'Courier New', monospace;
		}
		.font-calibri {
			font-family: calibri;
		}
	</style>
	
	<div class="container p-5">
		<div class="text-center">
			<h1 class="text-muted font-lucida">We, The <span class="text-warning">Frustrated Engineers</span></h1><br>
			<span class="fa fa-users fa-4x text-muted"></span><br><br><br>
			<div class="team-member">
				<h5><span class="text-warning font-calibri">B519012</span> <span class="text-light font-lucida">- Anshuman Mishra</span></h5><br>
				<h5><span class="text-warning font-calibri">B519017</span> <span class="text-light font-lucida">- Bibhu Prasad Samanta</span></h5><br>
				<h5><span class="text-warning font-calibri">B519028</span> <span class="text-light font-lucida">- Mohit Kumar</span></h5><br>
			</div>
		</div>
	</div>

<?php
  if(isset($conn)) {mysqli_close($conn);}
  require_once "./template/footer.php";
?>
