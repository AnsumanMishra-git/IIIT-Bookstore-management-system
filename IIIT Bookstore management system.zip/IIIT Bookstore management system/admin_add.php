<?php
	session_start();
	require_once "./functions/admin.php";
	$title = "Add new book";
	require "./template/header.php";
	require "./functions/database_functions.php";
	$conn = db_connect();

	if(isset($_POST['add'])){
		$isbn = trim($_POST['isbn']);
		$isbn = mysqli_real_escape_string($conn, $isbn);

		$title = trim($_POST['title']);
		$title = mysqli_real_escape_string($conn, $title);

		$author = trim($_POST['author']);
		$author = mysqli_real_escape_string($conn, $author);

		$descr = trim($_POST['descr']);
		$descr = mysqli_real_escape_string($conn, $descr);

		$price = floatval(trim($_POST['price']));
		$price = mysqli_real_escape_string($conn, $price);


		// add image
		if(isset($_FILES['image']) && $_FILES['image']['name'] != ""){
			$image = $_FILES['image']['name'];
			$directory_self = str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']);
			$uploadDirectory = $_SERVER['DOCUMENT_ROOT'] . $directory_self . "bootstrap/img/";
			$uploadDirectory .= $image;
			move_uploaded_file($_FILES['image']['tmp_name'], $uploadDirectory);
		}



		$query = "INSERT INTO books VALUES ('" . $isbn . "', '" . $title . "', '" . $author . "', '" . $image . "', '" . $descr . "', '" . $price . "')";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't add new data " . mysqli_error($conn);
			exit;
		} else {
			header("Location: admin_book.php");
		}
	}
?>
	<style type="text/css">
        .wrapper { 
            width:50%;
            padding:20px; 
        }
    </style>

    <section class="pt-5 pb-5">
	    <div class="wrapper mx-auto shadow bg-light rounded">
			<form method="post" action="admin_add.php" enctype="multipart/form-data">
				<div class="d-flex justify-content-between">
					<h5><b>Add a Book</b></h5>
					<a href="admin_book.php" class="btn btn-outline-primary">Go Back</a>
				</div><br>
				<table class="table">
					<tr>
						<th>ISBN</th>
						<td><input type="text" name="isbn" class="form-control"></td>
					</tr>
					<tr>
						<th>Title</th>
						<td><input type="text" name="title" class="form-control" required></td>
					</tr>
					<tr>
						<th>Author</th>
						<td><input type="text" name="author" class="form-control" required></td>
					</tr>
					<tr>
						<th>Image</th>
						<td><input type="file" name="image" class="form-control"></td>
					</tr>
					<tr>
						<th>Description</th>
						<td><textarea name="descr" cols="40" rows="5" class="form-control"></textarea></td>
					</tr>
					<tr>
						<th>Price</th>
						<td><input type="text" name="price" class="form-control" required></td>
					</tr>
				</table>
				<div class="w-100 text-right">
					<input type="reset" value="cancel" class="btn btn-light">
					<input type="submit" name="add" value="Add new book" class="btn btn-primary">
				</div>
			</form>
		</div>
	</section>
	<br/>
<?php
	if(isset($conn)) {mysqli_close($conn);}
	require_once "./template/footer.php";
?>
