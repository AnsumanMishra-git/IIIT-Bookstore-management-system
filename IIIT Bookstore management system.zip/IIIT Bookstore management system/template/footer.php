      	
      <hr>

      	<?php if(isset($title) && $title == "Index") { ?>
	      	<footer class="footer index-page">
	      		<div class="footer-wrapper">
		        	<div class="text-center pb-3">
		        	 	<small>DEVELOPED BY <a href="team.php" class="text-warning">FRUSTRATED ENGINEERS</a></small>
		        	</div>
		      	</div>
		   	</footer>

	   	<?php } else { ?>
	    	<footer class="footer">
	      		<div class="footer-wrapper">
		        	<div class="text-center pb-3">
		        	 	<small>DEVELOPED BY <a href="team.php" class="text-warning">FRUSTRATED ENGINEERS</a></small>
		        	</div>
		      	</div>
		   	</footer>
    	<?php } ?>

    </div> <!-- /container -->

   
  </body>
</html>
