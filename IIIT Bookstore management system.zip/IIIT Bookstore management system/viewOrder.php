<?php
	session_start();
	require_once "./functions/admin.php";
	$title = "View Orders";
	require_once "./template/header.php";
	require_once "./functions/database_functions.php";
	$conn = db_connect();
	$result = getOrders($conn);
?>

<section class="p-5 m-2 ml-4 mr-4 bg-light rounded">
	<div class="d-flex justify-content-between">
		<h2>Order Details</h2>
		<a href="admin_book.php" class="btn btn-outline-primary">Go Back</a>
	</div>
	<table class="table table-bordered" style="margin-top: 20px">
		<tr class="table-info">
			<th>Name</th>
			<th>OrderId</th>
			<th>Date</th>
			<th>ISBN</th>
      		<th>Quantity</th>
      		<th>Address</th>
		</tr>
		<?php while($row = mysqli_fetch_assoc($result)){ ?>
		<tr>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['orderid']; ?></td>
			<td><?php echo $row['date']; ?></td>
			<td><?php echo $row['book_isbn']; ?></td>
      <td><?php echo $row['quantity']; ?></td>
      <td><?php echo $row['address']; ?></td>

		</tr>
		<?php } ?>
	</table>
</section>

<?php
	if(isset($conn)) {mysqli_close($conn);}
	require_once "./template/footer.php";
?>
