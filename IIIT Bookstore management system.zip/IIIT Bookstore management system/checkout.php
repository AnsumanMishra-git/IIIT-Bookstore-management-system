<?php
	// the shopping cart needs sessions, to start one
	/*
		Array of session(
			cart => array (
				book_isbn (get from $_GET['book_isbn']) => number of books
			),
			items => 0,
			total_price => '0.00'
		)
	*/
	session_start();
	require_once "./functions/database_functions.php";
	// print out header here
	$title = "Checking out";
	require "./template/header.php";

	if(isset($_SESSION['cart']) && (array_count_values($_SESSION['cart']))){
?>

	<style type="text/css">
        .wrapper { 
            width:100%;
            padding:20px; 
        }
    </style>

<section class="pt-5 pb-5 pl-3 pr-3">
	<div class="wrapper shadow">
		<div class="row">
			<div class="col-lg-8 col-md-6 col-sm-12">
				<h5 class="text-muted"><b>Books in Basket</b></h5>
				<table class="table table-bordered table-dark">
					<tr>
						<th>Item</th>
						<th>Price</th>
				    	<th>Quantity</th>
				    	<th>Total</th>
				    </tr>
				    	<?php
						    foreach($_SESSION['cart'] as $isbn => $qty){
								$conn = db_connect();
								$book = mysqli_fetch_assoc(getBookByIsbn($conn, $isbn));
						?>
					<tr>
						<td><?php echo $book['book_title'] . " by " . $book['book_author']; ?></td>
						<td><?php echo "$" . $book['book_price']; ?></td>
						<td><?php echo $qty; ?></td>
						<td><?php echo "$" . $qty * $book['book_price']; ?></td>
					</tr>
					<?php } ?>
					<tr>
						<th>&nbsp;</th>
						<th>&nbsp;</th>
						<th><?php echo $_SESSION['total_items']; ?></th>
						<th><?php echo "$" . $_SESSION['total_price']; ?></th>
					</tr>
				</table>
				<div class="w-100 text-right">
					<a href="cart.php" class="btn btn-primary">Back to Cart</a>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-sm-12 pt-2 pb-2 border bg-light rounded">
				<h5><b>Checkout</b></h5><br>
				<form method="post" action="purchase.php" class="form-horizontal">
					<?php if(isset($_SESSION['err']) && $_SESSION['err'] == 1){ ?>
						<p class="text-danger">All fields have to be filled</p>
						<?php } ?>
					<div class="form-group">
						<label for="name" class="control-label col-md-4 font-weight-bold">Name</label>
						<div class="col-12">
							<input type="text" name="name" class="col-12 form-control">
						</div>
					</div>
					<div class="form-group">
						<label for="address" class="control-label col-md-4 font-weight-bold">Address</label>
						<div class="col-12">
							<input type="text" name="address" class="col-12 form-control">
						</div>
					</div>
					<div class="form-group">
						<label for="city" class="control-label col-md-4 font-weight-bold">City</label>
						<div class="col-12">
							<input type="text" name="city" class="col-12 form-control">
						</div>
					</div>
					<div class="form-group">
						<label for="zip_code" class="control-label col-md-4 font-weight-bold">Zip Code</label>
						<div class="col-12">
							<input type="text" name="zip_code" class="col-12 form-control">
						</div>
					</div>
					<div class="form-group">
						<label for="country" class="control-label col-md-4 font-weight-bold">Country</label>
						<div class="col-12">
							<input type="text" name="country" class="col-12 form-control">
						</div>
					</div>
					<div class="form-group text-right">
						<input type="submit" name="submit" value="Purchase" class="btn btn-success">
					</div>
				</form>
				<!-- <p class="lead">Please press Purchase to confirm your purchase, or Continue Shopping to add or remove items.</p> -->
			</div>
		</div>
	</div>
</section>
<?php
	} else {
		echo "<p class=\"text-warning\">Your cart is empty! Please make sure you add some books in it!</p>";
	}
	if(isset($conn)){ mysqli_close($conn); }
	require_once "./template/footer.php";
?>
