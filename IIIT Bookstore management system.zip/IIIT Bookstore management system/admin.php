<?php
	$title = "Administration section";
	require_once "./template/header.php";
?>
	<style type="text/css">
        .wrapper { 
            width:350px;
            padding:20px; 
        }
    </style>

	<div class="wrapper mt-5 mb-3 mx-auto shadow bg-light rounded">
		<h2 class="text-center text-primary">Admin Panel</h2>
		<form class="form-horizontal" method="post" action="admin_verify.php">
			<div class="form-group">
				<label for="name" class="control-label col-md-12 font-weight-bold"><span class="fa fa-user"></span>&nbsp;Name</label>
				<div class="col-md-12">
					<input type="text" name="name" class="form-control">
				</div>
			</div>
			<div class="form-group">
				<label for="pass" class="control-label col-md-12 font-weight-bold"><span class="fa fa-key"></span>&nbsp;Password</label>
				<div class="col-md-12">
					<input type="password" name="pass" class="form-control">
				</div>
			</div><hr>
			<div class="form-group text-center">
				<input type="submit" name="submit" class="btn btn-primary">
			</div>
		</form>
	</div>

<?php
	require_once "./template/footer.php";
?>