<?php
	session_start();
	require_once "./functions/admin.php";
	$title = "List book";
	require_once "./template/header.php";
	require_once "./functions/database_functions.php";
	$conn = db_connect();
	$result = getAll($conn);
?>	
	
	<section class="pt-5 mr-4 ml-4">
		<div class="w-100 d-flex justify-content-between">
			<div class="d-flex">
				<a href="admin_add.php" class="btn btn-info mr-2">Add new book</a>
				<a href="viewOrder.php" class="btn btn-outline-primary ml-2">Orders</a>
			</div>
			<div>
				<a href="admin_signout.php" class="btn btn-danger">Sign out!</a>
			</div>
		</div>
	</section>

	<section class="pl-3 pr-3">
		<table class="table table-bordered table-hover bg-light" style="margin-top: 20px">
			<tr class="table-primary">
				<th>ISBN</th>
				<th>Title</th>
				<th>Author</th>
				<th>Image</th>
				<th>Description</th>
				<th>Price</th>
				<th>&nbsp;</th>
				<th>&nbsp;</th>
			</tr>
			<?php while($row = mysqli_fetch_assoc($result)){ ?>
			<tr>
				<td><?php echo $row['book_isbn']; ?></td>
				<td><?php echo $row['book_title']; ?></td>
				<td><?php echo $row['book_author']; ?></td>
				<td><?php echo $row['book_image']; ?></td>
				<td><?php echo $row['book_descr']; ?></td>
				<td><?php echo $row['book_price']; ?></td>
				<td><a href="admin_edit.php?bookisbn=<?php echo $row['book_isbn']; ?>">Edit</a></td>
				<td><a href="admin_delete.php?bookisbn=<?php echo $row['book_isbn']; ?>">Delete</a></td>
			</tr>
			<?php } ?>
		</table>
	</section>

<?php
	if(isset($conn)) {mysqli_close($conn);}
	require_once "./template/footer.php";
?>
