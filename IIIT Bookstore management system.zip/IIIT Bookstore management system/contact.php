<?php
  $title = "Contact";
  require_once "./template/header.php";
  require_once "./functions/database_functions.php";

?>
    <!-- <div class="row">
        <div class="col-md-3"></div>
		<div class="col-md-6 text-center">
			<form class="form-horizontal" action="process_contact.php" method="POST">
			  	<fieldset>
				    <legend>Contact</legend>
				    <p class="lead">I’d love to hear from you! Complete the form to send me an email.</p>
				    <div class="form-group">
				      	<label for="inputName" class="col-lg-2 control-label">Name</label>
				      	<div class="col-lg-10">
				        	<input type="text" class="form-control" id="inputName" placeholder="Name"  name='nm'>
				      	</div>
				    </div>
				    <div class="form-group">
				      	<label for="inputEmail" class="col-lg-2 control-label">Email</label>
				      	<div class="col-lg-10">
				        	<input type="text" class="form-control" id="inputEmail" placeholder="Email" name='email'>
				      	</div>
				    </div>
				    <div class="form-group">
				      	<label for="textArea" class="col-lg-2 control-label">Textarea</label>
				      	<div class="col-lg-10">
				        	<textarea class="form-control" rows="3" id="textArea" name='query'></textarea>
				        	<span class="help-block">A longer block of help text that breaks onto a new line and may extend beyond one line.</span>
				      	</div>
				    </div>
				    <div class="form-group">
				      	<div class="col-lg-10 col-lg-offset-2">
				        	<button type="reset" class="btn btn-default">Cancel</button>
				        	<button type="submit" class="btn btn-primary">Submit</button>
				      	</div>
				    </div>
			  	</fieldset>
			</form>
		</div>
		<div class="col-md-3"></div>
    </div> -->

		<style type="text/css">
	        .wrapper { 
	            width:450px;
	            padding:20px; 
	        }
	    </style>

    	<div class="wrapper mx-auto shadow mt-4 mb-5 bg-light rounded">
			<form class="form-horizontal" action="process_contact.php" method="POST">
			  	<fieldset>
				    <legend class="text-center"><strong>Contact</strong></legend>
				    <p class="lead text-center">I’d love to hear from you! Complete the form to send me an email.</p>
				    <div class="form-group">
				      	<label for="inputName" class="col-lg-2 control-label font-weight-bold">Name</label>
				      	<div class="col-lg-12">
				        	<input type="text" class="form-control" id="inputName" name='nm'>
				      	</div>
				    </div>
				    <div class="form-group">
				      	<label for="inputEmail" class="col-lg-2 control-label font-weight-bold">Email</label>
				      	<div class="col-lg-12">
				        	<input type="text" class="form-control" id="inputEmail" name='email'>
				      	</div>
				    </div>
				    <div class="form-group">
				      	<label for="textArea" class="col-lg-4 control-label font-weight-bold">Your Message</label>
				      	<div class="col-lg-12">
				        	<textarea class="form-control" rows="3" id="textArea" name='query'></textarea>
				        	<small class="help-block text-muted">A longer block of help text that breaks onto a new line and may extend beyond one line.</small>
				      	</div>
				    </div><hr>
				    <div class="form-group">
				      	<div class="float-right">
				        	<button type="reset" class="btn btn-light">Cancel</button>
				        	<button type="submit" class="btn btn-primary">Submit</button>
				      	</div>
				    </div>
			  	</fieldset>
			</form>
		</div>


<?php
  require_once "./template/footer.php";
?>
