<?php
  session_start();
  $count = 0;
  // connecto database
  
  $title = "Index";
  require_once "./template/header.php";
  require_once "./functions/database_functions.php";
  $conn = db_connect();
  $row = select4LatestBook($conn);
?>

      <!-- Example row of columns -->
     <!--  <h5 class="display-4 text-center text-muted">Latest books</h5>
      <section class="p-3">
        <div class="d-flex flex-wrap justify-content-between">
          <?php foreach($row as $book) { ?>
          <div class="card mb-5 border-0 shadow" style="width:250px;">
            <img class="card-img-top img-responsive" src="./bootstrap/img/<?php echo $book['book_image']; ?>" alt="Card image cap">
            <div class="card-body">
              <p class="lead"><?php echo $book['book_title']; ?></p>
              <a href="book.php?bookisbn=<?php echo $book['book_isbn']; ?>" class="stretched-link"></a>
            </div>
          </div>
          <?php } ?>
        </div>
      </section> -->


<?php
  if(isset($conn)) {mysqli_close($conn);}
  require_once "./template/footer.php";
?>
